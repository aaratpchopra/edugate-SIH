package xyz.aaratprasadchopra.address;

public interface AddressService {
	/**
	 * 
	 * Saves The Address in the DB.
	 * 
	 * @param address Takes in an instance of _Address_.
	 * @return Returns True.
	 */
	boolean save(Address address);
}
