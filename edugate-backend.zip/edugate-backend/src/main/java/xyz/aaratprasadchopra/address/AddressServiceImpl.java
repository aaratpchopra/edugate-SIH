package xyz.aaratprasadchopra.address;

import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class AddressServiceImpl implements AddressService {
	private final AddressRepository addressRepository;
	
	@Override
	public boolean save(Address address) {
		this.addressRepository.save(address);
		return true;
	}
}
