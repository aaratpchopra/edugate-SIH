package xyz.aaratprasadchopra.login;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import lombok.AllArgsConstructor;
import xyz.aaratprasadchopra.profile.ProfileResponse;
import xyz.aaratprasadchopra.university.UniversityService;

@AllArgsConstructor
@RestController
@RequestMapping("/api/login")
public class LoginResource {
	private final UniversityService universityService;

	@GetMapping
	public ProfileResponse login(@RequestParam("email") String emailId) {
		var university = this.universityService.getByEmail(emailId);
		return new ProfileResponse(university.getName(), university.getAddress().getStreet(), university.getAddress().getCity(), university.getAddress().getState(), university.getEmail(), university.getUniversityWebsite(), university.getRegistrationId());
	}
}
