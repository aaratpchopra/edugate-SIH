package xyz.aaratprasadchopra.s3;

import org.springframework.web.multipart.MultipartFile;

public interface S3Service {
	boolean uploadFile(String uniqueId, MultipartFile file);
}
