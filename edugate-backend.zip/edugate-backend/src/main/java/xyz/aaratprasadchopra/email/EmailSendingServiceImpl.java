package xyz.aaratprasadchopra.email;

import java.time.LocalDateTime;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import xyz.aaratprasadchopra.exceptions.TokenExpiredException;
import xyz.aaratprasadchopra.exceptions.TokenNotFoundException;
import xyz.aaratprasadchopra.token.ConfirmationTokenService;
import xyz.aaratprasadchopra.university.UniversityService;

@Service
public class EmailSendingServiceImpl implements EmailSendingService {
	private final JavaMailSender mailSender;
	private final ConfirmationTokenService confirmationTokenService;
	private final UniversityService universityService;

	@Value("${spring.mail.username}")
	private String fromEmail;

	public EmailSendingServiceImpl(JavaMailSender mailSender, ConfirmationTokenService confirmationTokenService,
			UniversityService universityService) {
		super();
		this.mailSender = mailSender;
		this.confirmationTokenService = confirmationTokenService;
		this.universityService = universityService;
	}

	@Override
	@Async
	public String sendEmail(String to, String email) {
		try {
			var mimeMessage = this.mailSender.createMimeMessage();
			var mimeMessageHelper = new MimeMessageHelper(mimeMessage, "utf-8");
			mimeMessageHelper.setText(email, true);
			mimeMessageHelper.setTo(to);
			mimeMessageHelper.setSubject("Edugate: Email Confirmation");
			mimeMessageHelper.setFrom(this.fromEmail);
			this.mailSender.send(mimeMessage);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		return "Email Sent To " + to;
	}

	@Override
	@Transactional
	public String confirmToken(String token) {
		var confirmationToken = this.confirmationTokenService.getConfirmationToken(token).orElseThrow(() -> new TokenNotFoundException("The Token Was Not Found!" + " - " + token));

		if (confirmationToken.getConfirmedAt() != null)
			throw new IllegalStateException("The Token, " + token + " is Already Confirmed!");

		var expiredAt = confirmationToken.getExpiresAt();

		if (expiredAt.isBefore(LocalDateTime.now()))
			throw new TokenExpiredException("The Token is Expired!");

		this.universityService.universityEmailVerified(confirmationToken.getUniversity().getEmail());
		return "_link_"; // Redirection to the confirmation page
	}
}
