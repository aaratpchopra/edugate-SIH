package xyz.aaratprasadchopra.university;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import xyz.aaratprasadchopra.address.AddressService;
import xyz.aaratprasadchopra.exceptions.EmailTakenException;
import xyz.aaratprasadchopra.exceptions.UniversityNotFoundException;
import xyz.aaratprasadchopra.token.ConfirmationToken;
import xyz.aaratprasadchopra.token.ConfirmationTokenService;

@Service
@AllArgsConstructor
public class UniverstityServiceImpl implements UniversityService {
	private final UniversityRepository universityRepo;
	private final AddressService addressService;
	private final ConfirmationTokenService confirmationTokenService;
	private final BCryptPasswordEncoder encoder;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		System.out.println(username);
		return this.universityRepo.findByEmail(username).orElseThrow(() -> new UsernameNotFoundException("No Email Were Found By The Entered Email."));
	}

	@Override
	public String save(University university) {
		var isEmailTaken = this.universityRepo.findByEmail(university.getEmail()).isPresent();
		if (isEmailTaken) {
			throw new EmailTakenException("The Email Has Been Taken!");
		}
		var encodedPassword = this.encoder.encode(university.getPassword());
		university.setPassword(encodedPassword);
		this.addressService.save(university.getAddress());

		var token = UUID.randomUUID().toString();
		var confirmationToken = new ConfirmationToken(UUID.randomUUID().toString(), token, LocalDateTime.now(), LocalDateTime.now().plusHours(1), university);
		university.setConfirmationToken(confirmationToken);
		this.universityRepo.save(university);
		this.confirmationTokenService.save(confirmationToken);
		return token;
	}

	@Override
	public University getByUniqueId(String uniqueId) {
		return this.universityRepo.findById(uniqueId).orElseThrow();
	}

	@Override
	public void universityEmailVerified(String email) {
		this.universityRepo.verifyUniversityEmail(email);
	}

	@Override
	public List<University> getUniversities() {
		return this.universityRepo.findAll();
	}

	@Override
	public University getByEmail(String email) {
		return this.universityRepo.findByEmail(email).orElseThrow(() -> new UniversityNotFoundException("No University Found By This Email"));
	}
}
