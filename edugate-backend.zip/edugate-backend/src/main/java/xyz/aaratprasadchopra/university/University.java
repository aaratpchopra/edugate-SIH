package xyz.aaratprasadchopra.university;

import java.util.Collection;
import java.util.Collections;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import xyz.aaratprasadchopra.address.Address;
import xyz.aaratprasadchopra.roles.APP_ROLE;
import xyz.aaratprasadchopra.token.ConfirmationToken;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "universities")
public class University implements UserDetails {
	private static final long serialVersionUID = 1L;

	@Id
	private String uniqueId;
	
	@Column(nullable = false)
	private String name;
	
	@Column(nullable = false)
	private String email;
	
	@Column(nullable = false)
	private String password;

	@Column(nullable = false)
	private String registrationId;
	
	@Column(nullable = false)
	private String universityWebsite;

	@Column(nullable = false)
	private Boolean isEmailVerified = false;
	
	@Column(nullable = false)
	private Boolean isUniversityVerified = false;
	
	@Column(nullable = false)
	private Boolean isFake = true;

	@Enumerated(EnumType.STRING)
	private APP_ROLE role;

	@OneToOne(mappedBy = "university")
	private ConfirmationToken confirmationToken;

	@OneToOne
	@JoinColumn(name = "address_unique_id")
	private Address address;

	public University(String uniqueId, String name, String email, String password, boolean isFake, String registrationId, String universityWebsite, APP_ROLE role, Address address) {
		this.uniqueId = uniqueId;
		this.name = name;
		this.email = email;
		this.password = password;
		this.isFake = isFake;
		this.registrationId = registrationId;
		this.universityWebsite = universityWebsite;
		this.role = role;
		this.address = address;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		var grantAuthority = new SimpleGrantedAuthority("ROLE_" + this.role.name());
		return Collections.singletonList(grantAuthority);
	}

	@Override
	public String getPassword() {
		return this.password;
	}

	@Override
	public String getUsername() {
		return this.email;
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return this.isEmailVerified;
	}
}
