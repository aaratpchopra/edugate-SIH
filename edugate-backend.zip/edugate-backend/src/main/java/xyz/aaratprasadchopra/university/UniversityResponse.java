package xyz.aaratprasadchopra.university;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UniversityResponse {
	private String uniqueId;
	private String name;
	private String address;
	private String city;
	private String state;
	private String country;
	private String website;
	private String pinCode;
}
