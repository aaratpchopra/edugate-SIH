package xyz.aaratprasadchopra.university;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface UniversityService extends UserDetailsService {
	String save(University university);
	University getByEmail(String email);
	
	/**
	 * 
	 * Gets a university instance from the DB if exists.
	 * 
	 * @param uniqueId
	 * @return
	 */
	University getByUniqueId(String uniqueId);
	
	/**
	 * 
	 * Gets all universities saved in the DB.
	 * 
	 * @return List of university instances/objects.
	 */
	List<University> getUniversities();
	
	/**
	 * 
	 * Updates the database is_verified attribute to true.
	 * 
	 * @param email Takes in a email for match and verifies it if exists.
	 */
	void universityEmailVerified(String email);
}
