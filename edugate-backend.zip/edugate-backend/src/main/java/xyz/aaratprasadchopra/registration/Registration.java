package xyz.aaratprasadchopra.registration;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Registration {
	private String universityName;
	private String email;
	private String password;
	private String registrationId;
	private String website;
	private String street;
	private String state;
	private String city;
	private String zipCode;
}
