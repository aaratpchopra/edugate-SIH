package xyz.aaratprasadchopra.filter;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SearchFilterResponse {
	private String universityUniqueId;
	private String universityName;
}
