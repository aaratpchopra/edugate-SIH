package xyz.aaratprasadchopra.token;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import xyz.aaratprasadchopra.university.University;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "tokens")
public class ConfirmationToken {

	@Id
	private String uniqueId;

	@Column(nullable = false)
	private String token;

	@Column(nullable = false)
	private LocalDateTime createdAt;
	private LocalDateTime confirmedAt;

	@Column(nullable = false)
	private LocalDateTime expiresAt;

	@OneToOne
	@JoinColumn(name = "university_unique_id")
	private University university;

	public ConfirmationToken(String uniqueId, String token, LocalDateTime createdAt, LocalDateTime expiresAt, University university) {
		super();
		this.uniqueId = uniqueId;
		this.token = token;
		this.createdAt = createdAt;
		this.expiresAt = expiresAt;
		this.university = university;
	}
}
