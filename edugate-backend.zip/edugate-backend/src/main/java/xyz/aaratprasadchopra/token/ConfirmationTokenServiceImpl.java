package xyz.aaratprasadchopra.token;

import java.util.Optional;

import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class ConfirmationTokenServiceImpl implements ConfirmationTokenService {
	private final ConfirmationTokenRepository repo;

	@Override
	public boolean save(ConfirmationToken token) {
		this.repo.save(token);
		return true;
	}

	@Override
	public Optional<ConfirmationToken> getConfirmationToken(String token) {
		return this.repo.findByToken(token);
	}

	@Override
	public boolean delete(String tokenUniqueId) {
		this.repo.deleteById(tokenUniqueId);
		return true;
	}

	@Override
	public boolean update(ConfirmationToken confirmationToken) {
		this.repo.save(confirmationToken);
		return true;
	}
}
