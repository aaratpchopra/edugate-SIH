package xyz.aaratprasadchopra.profile;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProfileResponse {
	private String universityName;
	private String street;
	private String city;
	private String state;
	private String email;
	private String website;
	private String registrationId;
}
