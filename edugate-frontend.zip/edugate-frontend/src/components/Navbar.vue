<template>
  <div class="navbar navbar-expand-lg navbar-light">
    <div class="container-fluid">
      <img
        src="../assets/Swan-by-Yuri-Kartashev-560x420.jpg"
        width="80"
        height="50"
      />

      <div class="collapse navbar-collapse">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <router-link
              style="color: white"
              class="nav-link active"
              :to="{ name: 'home' }"
              >Home</router-link
            >
          </li>

          <li class="nav-item">
            <router-link
              style="color: white"
              class="nav-link active"
              :to="{ name: 'universities' }"
              >HEIs</router-link
            >
          </li>

          <li class="nav-item">
            <router-link
              style="color: white"
              class="nav-link active"
              :to="{ name: 'about' }"
              >About</router-link
            >
          </li>
        </ul>
        <form class="d-flex">
          <router-link class="btn btn-outline-light" :to="{ name: 'login' }"
            >HEI Login</router-link
          >
        </form>
      </div>
    </div>
  </div>

  <!-- <div class="navigation-bar">
    <div id="navigation-container">
      <img
        src="../assets/Swan-by-Yuri-Kartashev-560x420.jpg"
        width="100"
        height="70"
      />

      <ul>
        <li style="color: white">
          <router-link :to="{ name: 'home' }">Home</router-link>
        </li>
        <li>
          <router-link :to="{ name: 'about' }">About Us</router-link>
        </li>
        <li><a href="#">Universities</a></li>
        <li>
          <router-link :to="{ name: 'login' }">University Login</router-link>
        </li>
    <li>
          <router-link :to="{ name: 'registration' }">Register</router-link>
        </li> 
      </ul>
    </div>
  </div> -->
</template>

<script>
export default {
  name: "Navbar",
};
</script>

<style scoped>
.navbar {
  background-color: #180929;
}

ul li {
}

.p {
  color: white;
}

/* .logo {
  float: left;
}

#navigation-container {
  width: 1200px;
  margin: 0 auto;
  height: 70px;
}

.navigation-bar {
  background-color: #1a092b;
  height: 70px;
  width: 100%;
  text-align: center;
  padding: 0px;
  /* z-index: 1;
  margin-bottom: 1px;
}
.navigation-bar img {
  float: left;
}
.navigation-bar ul {
  padding: 0px;
  margin: 0px;
  text-align: end;
  display: inline-block;
  vertical-align: top;
}

.navigation-bar li {
  list-style-type: none;
  padding: 0px;
  height: 24px;
  margin-top: 4px;
  margin-bottom: 4px;
  display: inline;
  font-weight: 500;
}

.navigation-bar li a {
  color: white;
  font-size: 16px;
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  text-decoration: none;
  line-height: 70px;
  padding: 5px 15px;
  opacity: 0.7;
} */
</style>
