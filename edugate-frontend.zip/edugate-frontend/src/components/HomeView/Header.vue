<template>
  <div class="box">
    <img
      src="@/assets/university-new.jpg"
      alt="Flying Kites"
      style="
        width: 100%;
        height: 720px;
        object-fit: cover;
        object-position: 50% 50%;
        padding-bottom: 50px;
      "
    />
    <div class="overlap">
      <div class="captionBlock">
        <h1 style="color: black">EDUGATE</h1>
        <div style="">
          <h4 style="color: black; font-weight: bold">
            A Gateway To Quality Education
          </h4>
          <h4 style="color: black; font-weight: bold">
            A Place To Choose The Best Fit For Your Career
          </h4>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Header",
};
</script>

<style scoped>
.captionBlock {
  position: absolute;
  bottom: 290px;
  left: 50px;
  margin-top: 80px;
  height: 200px;
  /* background-color: #000000 !important; */
  color: rgb(255, 255, 255);
  top: 150px;
  padding-left: 150px;
  padding-right: 150px;
  /* padding-top: 100px !important; */
  font-size: 15px;
}
</style>
