<template>
  <div>
    <div class="container">
      <div class="mains">
        <h2 style="font-size: 50px">REVEALING GENUINE HEI FOR YOU</h2>
        <h6></h6>
      </div>
    </div>
    <div class="full">
      <!-- <a href="aboutUs.html"><button class="button">About Us</button></a> -->
      <router-link class="button" :to="{ name: 'about' }">About Us</router-link>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.mains {
  margin: 0 !important;
  outline: 0 !important;
  vertical-align: baseline !important;
  background: transparent !important;
  font-size: 40px !important;
  text-align: center !important;
  padding: 0px !important;
  margin: 10px !important;
  min-width: 980px !important;
  padding-top: 35px !important;
  padding-right: 40px !important;
  padding-bottom: 25px !important;
  padding-left: 20px !important;
}

.full {
  text-align: center;
  padding-bottom: 40px;
}
.button {
  padding: 15px 25px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color: black;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

.button:hover {
  background-color: #0b445a;
}

.button:active {
  background-color: #0c150c;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
.list {
  margin: 0 !important;
  outline: 0 !important;
  vertical-align: baseline !important;
  background: transparent !important;
  font-size: 40px !important;
  text-align: center !important;
  padding: 0px !important;
  margin: 10px !important;
  min-width: 980px !important;
  padding-top: 35px !important;
  padding-right: 40px !important;
  padding-bottom: 25px !important;
  padding-left: 20px !important;
}
</style>
