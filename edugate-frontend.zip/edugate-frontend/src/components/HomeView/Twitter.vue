<template>
  <blockquote class="twitter-tweet">
    <p lang="en" dir="ltr">
      Addressing the Grand Finale of Smart India Hackathon 2022. It offers a
      glimpse of India&#39;s Yuva Shakti.
      <a href="https://t.co/7TcixPgoqD">https://t.co/7TcixPgoqD</a>
    </p>
    &mdash; Narendra Modi (@narendramodi)
    <a
      href="https://twitter.com/narendramodi/status/1562812274951106560?ref_src=twsrc%5Etfw"
      >August 25, 2022</a
    >
  </blockquote>
  <!-- <script
    async
    src="https://platform.twitter.com/widgets.js"
    charset="utf-8"
  ></script> -->
</template>

<script>
export default {
  name: "Twitter",
};
</script>

<style></style>
