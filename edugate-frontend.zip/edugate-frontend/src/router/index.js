import { createRouter, createWebHistory } from "vue-router";
import HomeView from "../views/HomeView.vue";

const routes = [
  // HOME VIEW
  {
    path: "/",
    name: "home",
    component: HomeView,
  },
  // ABOUT VIEW
  {
    path: "/about",
    name: "about",
    component: () => import("@/views/AboutView.vue"),
  },
  // LOGIN VIEW
  {
    path: "/login",
    name: "login",
    component: () => import("@/views/LoginView.vue"),
  },
  // --------------------------   REGISTRATION ROUTES   ------------------------
  {
    path: "/registration",
    name: "registration",
    component: () => import("@/views/RegistrationView.vue"),
  },
  {
    path: "/registration/confirm-request",
    name: "confirmRequest",
    component: () => import("@/views/RequestEmailVerificationView.vue"),
  },
  {
    path: "/registration/confirmed",
    name: "confirmed",
    component: () => import("@/views/ConfirmedView.vue"),
  },
  // --------------------------   USER / STUDENT VIEW    ---------------------------
  {
    path: "/university/:id",
    name: "universityUserView",
    component: () => import("@/views/UniversityInfoView.vue"),
  },

  // -----------------------------    HEI PROFILE VIEW    ----------------------------
  {
    path: "/university/profile",
    name: "universityProfile",
    component: () => import("@/views/ProfileView.vue"),
  },

  {
    path: "/university/profile/add-course",
    name: "courseAdd",
    component: () => import("@/views/CourseDetailsView.vue"),
  },

  // UNIVERSITIES VIEW
  {
    path: "/universities",
    name: "universities",
    component: () => import("@/views/UniversitiesView.vue"),
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

export default router;
