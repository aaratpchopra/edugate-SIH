<template>
  <div class="container">
    <div class="mains">
      <h2 style="font-size: 50px">Detailed Registration Form</h2>
    </div>
  </div>
  <form action="" class="form-horizontal" method="get">
    <div class="container">
      <div class="container">
        <!-- <h4>Horizontal Form</h4> -->
        <div class="form-group has-success">
          <label class="control-label col-sm-2" for="id1">HEI Name</label>
          <div class="col-sm-6">
            <input
              disabled
              class="form-control"
              type="text"
              id="id1"
              placeholder="Enter the name of HEI"
            />
          </div>
        </div>

        <div class="form-group has-success">
          <label class="control-label col-sm-2" for="id2">Address</label>
          <div class="col-sm-6">
            <input
              disabled
              class="form-control"
              type="text"
              id="id2"
              placeholder="Enter HEI Address"
            />
          </div>
        </div>
        <div class="form-group has-success">
          <label class="control-label col-sm-2" for="id3">State</label>
          <div class="col-sm-6">
            <input
              disabled
              class="form-control"
              type="text"
              id="id3"
              placeholder="Enter State"
            />
          </div>
        </div>
        <div class="form-group has-success">
          <label class="control-label col-sm-2" for="id4">City</label>
          <div class="col-sm-6">
            <input
              disabled
              class="form-control"
              type="text"
              id="id4"
              placeholder="Enter City"
            />
          </div>
        </div>
        <div class="form-group has-success">
          <label class="control-label col-sm-2" for="id5">HEI Website</label>
          <div class="col-sm-6">
            <input
              disabled
              class="form-control"
              type="text"
              id="id5"
              placeholder="Enter Website"
            />
          </div>
        </div>
        <div class="form-group has-success">
          <label class="control-label col-sm-2" for="id6">Email Id</label>
          <div class="col-sm-6">
            <input
              disabled
              class="form-control"
              type="email"
              id="id6"
              placeholder="Enter Email Id"
            />
          </div>
        </div>
        <div class="form-group has-success">
          <label class="control-label col-sm-2" for="id6">Contact No.</label>
          <div class="col-sm-6">
            <input
              class="form-control"
              type="tel"
              pattern="[0-9]{3}[0-9]{3}[0-9]{4}"
              id="id7"
              placeholder="Enter Contact No."
            />
          </div>
        </div>
        <div class="form-group has-success">
          <label class="control-label col-sm-2" for="id6">About HEI</label>
          <div class="col-sm-6">
            <textarea
              class="form-control"
              id="id8"
              placeholder="Enter short description for HEI"
            ></textarea>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <input
            type="button"
            id="btnId"
            @click="addCourse"
            class="btn btn-primary"
            value="Add Course"
          />
          <input
            type="button"
            id="btnIdrm"
            class="btn btn-danger"
            value="Remove Course"
            @click="removeCourse"
          />
          <table
            id="tableId"
            class="table table-bordered table-hover"
            cellspacing="0"
            width="100%"
          >
            <thead>
              <th>Sr. No.</th>
              <th>Course Name</th>
              <th>new column</th>
            </thead>

            <tbody></tbody>
          </table>
          <table>
            <tbody></tbody>
          </table>
        </div>
      </div>
    </div>
    <button type="submit" class="btn btn-primary" style="text-align: center">
      Submit
    </button>
  </form>
</template>

<script>
let srNum = 1;
let rawIndex = 0;

export default {
  name: "CourseDetailsView",
  methods: {
    addCourse() {
      let table = document.getElementById("tableId");
      let row = table.insertRow(-1);
      let cell1 = row.insertCell(0);
      let cell2 = row.insertCell(1);
      let cell3 = row.insertCell(2);
      cell1.innerHTML = srNum;
      cell2.innerHTML = `<input type="text" placeholder="Enter Course Name" required>`;
      cell3.innerHTML = `
      <input id="branch-${srNum}" value="Add Branch" class="btn btn-success" onclick="addBranch(this.id)" />
      <input type="button" id="rmbranch-${srNum}" class="btn btn-danger" value="Remove Branch" onclick="removeBranch(this.id)">
      <div class="data-div"><table class="table branch-${srNum}" id="brTbl-${srNum}" table-bordered"><thead><th>Branch Name</th><th>Eligibility</th><th>Duration</th><th>Seats Available</th></thead><tbody class="field"><tr><td><input type="text" placeholder="Enter Branch" required></td><td><input type="text" placeholder="Enter Eligibility" required></td><td data-name="sel" id="drop" required><select name="sel0"><option value="1" selected>1 Year</option><option value="2">2 Year</option><option value="3">3 Year</option><option value="3">4 Year</option><option value="3">5 Year</option></select></td><td><input type="text" placeholder="Enter Available Seats" required></td></tr></tbody></table></div>`;

      srNum++;
    },

    removeCourse() {
      let rowCount = document.getElementById("tableId").rows.length;
      if (rowCount > 0) {
        document.getElementById("tableId").deleteRow(-1);
        srNum--;
      } else {
        return;
      }
    },

    addBranch(clicked) {
      console.log(clicked);
      let sliced = clicked.slice(6);
      let tableid = `brTbl${sliced}`;
      // console.log(tableid);
      let table = document.getElementById(tableid);
      let row = table.insertRow(-1);
      let cell1 = row.insertCell(0);
      let cell2 = row.insertCell(1);
      let cell3 = row.insertCell(2);
      let cell4 = row.insertCell(3);
      cell1.innerHTML = `<input type="text" placeholder="Enter Branch" required>`;
      cell2.innerHTML = `<input type="text" placeholder="Enter Eligibility" required>`;
      cell3.setAttribute("data-name", "sel");
      cell3.setAttribute("id", "drop");
      cell3.required = true;
      cell3.innerHTML = `<select name="sel0"><option value="1" selected>1 Year</option><option value="2">2 Year</option><option value="3">3 Year</option><option value="3">4 Year</option><option value="3">5 Year</option></select>`;
      cell4.innerHTML = `<input type="text" placeholder="Enter Available Seats" required>`;
    },

    removeBranch(clicked) {
      console.log(clicked);
      let btn = document.getElementById(clicked);
      let sliced = clicked.slice(8);
      let tableid = `brTbl${sliced}`;
      let rowCount = document.getElementById(tableid).rows.length;
      if (rowCount > 1) {
        document.getElementById(tableid).deleteRow(-1);
      } else {
        return;
      }
    },
  },
};
</script>

<style></style>
