<template>
  <div class="home">
    <header>
      <Header />
    </header>

    <!-- <section>
      <Notifications />
    </section> -->

    <section>
      <SearchCollege />
    </section>

    <section>
      <Login />
    </section>

    <section>
      <Reviling />
    </section>
  </div>
</template>

<script>
// @ is an alias to /src

import Header from "@/components/HomeView/Header.vue";
import Reviling from "@/components/HomeView/Reviling.vue";
import Login from "../components/HomeView/Login.vue";
import SearchCollege from "../components/HomeView/SearchCollege.vue";
import Notifications from "@/components/HomeView/Notifications.vue";

export default {
  name: "HomeView",
  components: { Header, Reviling, Login, SearchCollege, Notifications },
};
</script>
