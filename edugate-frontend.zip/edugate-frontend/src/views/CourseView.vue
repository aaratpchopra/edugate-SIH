<template>
  <input
    type="button"
    id="btnId"
    @click="addCourse"
    class="btn btn-primary"
    value="Add Course"
  />

  <input
    type="number"
    v-model="serialNumberToRemove"
    placeholder="Enter Serial Number To Remove"
  />
  <button
    :disabled="serialNumberToRemove <= 0 || serialNumberToRemove === ''"
    @click="remove"
    class=""
  >
    Remove
  </button>

  <table id="tableId" class="table table-bordered" cellspacing="0" width="100%">
    <thead>
      <th>Sr. No.</th>
      <th>Course Name</th>
      <th>new column</th>
      <th></th>
    </thead>

    <tbody v-for="data in dataArrObj" :key="data.serialId">
      <tr>
        <td>{{ data.serialId }}</td>
        <td>
          <input
            type="text"
            placeholder="Enter Course Name"
            required
            v-model="courseName"
            @input="updateCourseName(data.serialId)"
          />
        </td>
        <td>
          <input
            type="button"
            id=""
            class="btn test btn-success"
            value="Add Branch"
          />
          <div class="data-div">
            <table class="table">
              <thead>
                <th>Branch Name</th>
                <th>Eligibility</th>
                <th>Duration</th>
                <th>Seats Available</th>
                <th>Remove</th>
              </thead>

              <tbody class="field">
                <tr>
                  <td>
                    <input
                      type="text"
                      placeholder="Enter Branch"
                      required
                      v-model="branchName"
                      @input="updateBranchName(data.serialId)"
                    />
                  </td>
                  <td>
                    <input
                      type="text"
                      placeholder="Enter Eligibility"
                      required
                      v-model="eligibility"
                    />
                  </td>
                  <td id="drop" required>
                    <select @change="optionSelected" name="sel0">
                      <option value="SELECT" disabled selected>SELECT</option>
                      <option value="1" selected>1 Year</option>
                      <option value="2">2 Year</option>
                      <option value="3">3 Year</option>
                      <option value="3">4 Year</option>
                      <option value="3">5 Year</option>
                    </select>
                  </td>
                  <td>
                    <input
                      type="text"
                      placeholder="Enter Available Seats"
                      required
                      v-model="seatsAvailable"
                    />
                  </td>
                  <td>
                    <input
                      type="button"
                      id="branchRemove"
                      class="btn btn-danger"
                      value="Remove Branch"
                    />
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </td>
        <td>
          <input
            type="button"
            id="courseRemove"
            class="btn btn-danger"
            value="Remove Course"
          />
        </td>
      </tr>
    </tbody>
  </table>

  <button @click="click">CLICK</button>

  <!-- <script>
    $("#btnId").on("click", function () {
      $("#tableId").append(
        "
        <tr>
            <td>" + globalCount + '</td>
            <td>
                <input type="text" placeholder="Enter Course Name" required 
            </td>
            <td>
                <input type="button" id="" class="btn test btn-success" value="Add Branch" onclick="addNewSubRow()">
                <div class="data-div">
                    <table class="table table-bordered">
                        <thead>
                            <th>Branch Name</th>
                            <th>Eligibility</th>
                            <th>Duration</th>
                            <th>Seats Available</th>
                            <th></th>
                        </thead>

                        <tbody class="field">
                            <tr>
                                <td>
                                    <input type="text" placeholder="Enter Branch" required>
                                </td>
                                <td>
                                    <input type="text" placeholder="Enter Eligibility" required>
                                </td>
                                <td data-name="sel" id="drop" required>
                                    <select name="sel0">
                                        <option value="1" selected>1 Year</option>
                                        <option value="2">2 Year</option>
                                        <option value="3">3 Year</option>
                                        <option value="3">4 Year</option>
                                        <option value="3">5 Year</option>
                                    </select>
                                </td>
                                <td>
                                    <input type="text" placeholder="Enter Available Seats" required>
                                </td>
                                <td>
                                    <input type="button" id="branchRemove" class="btn btn-danger" value="Remove Branch">
                                </td>
                            </tr>
                            
                        </tbody>
                    </table>
                </div>
            </td>
            <td>
                <input type="button" id="courseRemove" class="btn btn-danger" value="Remove Course">
            </td>
        </tr>
    </tbody>'
      );
      globalCount++;
      console.log(document.querySelector(".test").id);
    });
  </script> -->
</template>

<script>
export default {
  name: "CourseView",
  data() {
    return {
      serialNumberToRemove: "",
      dataArrObj: [],
      serialCount: 0,

      // ACTUALL DATA
      courseName: "",
      branchName: "",
      eligibility: "",
      duration: "",
      seatsAvailable: "",
    };
  },
  methods: {
    optionSelected(e) {
      console.log(e);
    },
    click() {
      console.log(this.dataArrObj);
    },
    updateCourseName(serialId) {
      console.log(serialId);
      //   const currentData = this.dataArrObj.at();
    },
    addCourse() {
      this.serialCount++;
      this.dataArrObj.push({
        serialId: this.serialCount,
        courseName: this.courseName,
        branchName: this.branchName,
        eligibility: this.eligibility,
        duration: this.duration,
        seats: this.seatsAvailable,
      });

      console.log(this.data);
    },
  },
};
</script>

<style scoped>
/* .td {
  display: flex;
  background-color: azure;
}

.data-div {
  margin: 10px;
}

.field {
  display: flex;
  align-items: center;
  justify-items: center;
} */
</style>
