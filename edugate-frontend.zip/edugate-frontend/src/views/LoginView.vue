<template>
  <section class="intro">
    <div
      class="bg-image"
      style="
        background-image: url('http://www.maxmorganconsultants.com/assets/images/abroad/india1.jpg');
        height: 800px;
      "
    >
      <div class="container h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
          <div class="col-lg-8 col-xl-6">
            <div class="card mask-custom">
              <div class="card rounded-3">
                <div class="card-body p-4 p-md-5">
                  <h3 class="mb-4 pb-2 pb-md-0 mb-md-5 px-md-2 text-center">
                    Login
                  </h3>

                  <form>
                    <!-- Email input -->
                    <div class="form-outline form-white mb-4">
                      <input
                        type="email"
                        id="form3Example3"
                        class="form-control form-control-lg"
                        required
                        v-model="emailId"
                      />
                      <label class="form-label" for="form3Example3"
                        >Email</label
                      >
                    </div>

                    <!-- Password input -->
                    <div class="form-outline form-white mb-4">
                      <input
                        type="password"
                        id="form3Example4"
                        class="form-control form-control-lg"
                        required
                        v-model="password"
                      />
                      <label class="form-label" for="form3Example4"
                        >Password</label
                      >
                    </div>

                    <!-- <input
                      type="submit"
                      value="Login"
                      class="btn btn-light btn-block mb-4"
                    /> -->
                    <!-- <button class="btn btn-light btn-block mb-4" @click="login">
                      Login
                    </button> -->

                    <router-link
                      class="btn btn-light btn-block mb-4"
                      :to="{ name: 'universityProfile' }"
                      >Login</router-link
                    >

                    <!-- Submit button -->
                    <!-- <a href="profile.html"
                      ><button
                        type="submit"
                        class="btn btn-light btn-block mb-4"
                      >
                        Login
                      </button></a
                    > -->
                    <div class="text-center">
                      <p>
                        HEI Not Registered?
                        <router-link
                          :to="{ name: 'registration' }"
                          style="text-decoration: none"
                          >Register</router-link
                        >
                      </p>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: "LoginView",
  data() {
    return {
      emailId: "",
      password: "",
    };
  },

  methods: {
    login(e) {
      e.preventDefault();
      this.$router.push({ query: { email: this.emailId } });
      fetch(`http://localhost:8080/api/registration/login`)
        .then((res) => res.json())
        .then((data) => console.log(data))
        .catch((err) => console.log(err));
    },
  },
};
</script>

<style scoped>
#menu {
  float: right;
}

.intro {
  height: 100%;
}

@media (min-width: 550px) and (max-width: 750px) {
  .intro {
    height: 750px;
  }
}

@media (min-width: 800px) and (max-width: 850px) {
  .intro {
    height: 750px;
  }
}

.form-label {
  color: black;
}
</style>
