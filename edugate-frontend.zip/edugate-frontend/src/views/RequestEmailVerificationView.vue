<template>
  <Loader v-show="isUpdatingAndSendingEmail" />
  <!-- <ModalBox /> -->
  <div class="main-div">
    <div class="inner-div">
      <img src="@/assets/mail.png" width="200" height="200" />
      <h1>Please Verify Your Email</h1>

      <p>
        We've Sent An Email To <strong>{{ emailId }}</strong> To Verify you
        Email Address and Activate Your Account. The Link Is Valid Only For An
        Hour.
      </p>
      <p>
        <span @click="clickHere">Click Here</span>
        If You Didn't Receive An Email Or If The Link Got Expired.
      </p>
    </div>
  </div>
</template>

<script>
import { REGISTRATION_API_URL } from "@/Global";
import Loader from "@/components/Loader.vue";
import ModalBox from "../components/GlobalView/ModalBox.vue";
import ProfileView from "./ProfileView.vue";

export default {
  name: "RequestEmailVerificationView",
  created() {
    this.universityUniqueId = this.$route.query.id;
    this.emailId = this.$route.query.email;
  },
  data() {
    return {
      universityUniqueId: String,
      emailId: String,
      constructedURL: String,
      isUpdatingAndSendingEmail: false,
    };
  },
  methods: {
    clickHere() {
      this.isUpdatingAndSendingEmail = true;
      fetch(
        REGISTRATION_API_URL +
          "/resend-new-token" +
          "?id=" +
          this.universityUniqueId
      )
        .then((res) => res.ok)
        .then((val) => {
          this.isUpdatingAndSendingEmail = false;
          console.log(val);
        })
        .catch((err) => {
          // err if failed!
          console.log(err);
        });
    },
  },
  components: { Loader, ModalBox, ProfileView },
};
</script>

<style scoped>
.main-div {
  display: flex;
  width: 100%;
  /* height: calc(100vh - 70px - 220px); */
  align-items: center;
  justify-content: center;
  margin-top: 50px;
}

.inner-div {
  display: flex;
  flex-direction: column;
  align-items: center;
}

img {
  margin-bottom: 10px;
}

h1 {
  margin-top: 10px;
}

span {
  color: #85aac9;
  cursor: pointer;
}
</style>
