<template>
  <Loader v-show="showLoader" />
  <section class="bg-light p-5">
    <h3 class="pb-2">List of HEI/Universities/Colleges</h3>
    <div class="LIST OF COLLEGES" id="no-more-tables">
      <table class="table bg-white">
        <thead class="bg-dark text-light">
          <tr>
            <th scope="col">Serial No.</th>
            <th scope="col">Name</th>
            <th scope="col">Address</th>
            <th scope="col">Website</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(university, index) in universities" :key="index">
            <td data-title="Serial No.">
              <h5 class="text-center">{{ index + 1 }}</h5>
            </td>
            <td data-title="Institution/College Name">
              <router-link
                :to="{
                  name: 'universityUserView',
                  params: { id: university.uniqueId },
                }"
                >{{ university.name }}</router-link
              >
            </td>
            <td data-title="Address of the Institution/College">
              {{
                university.address +
                " " +
                university.city +
                " " +
                university.state +
                " " +
                university.country
              }}
            </td>
            <td data-title="Website link for preview the details">
              <a href="https://www.dei.ac.in/dei/">{{ university.website }}</a>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>
</template>

<script>
import { UNIVERSITIES_API_URL } from "@/Global";
import Loader from "@/components/Loader.vue";
export default {
  name: "UniversitiesView",
  data() {
    return {
      universities: [],
      showLoader: false,
    };
  },
  created() {
    this.showLoader = true;
    fetch(UNIVERSITIES_API_URL)
      .then((res) => res.json())
      .then((data) => {
        this.universities = data;
        this.showLoader = false;
      });
  },
  components: { Loader },
};
</script>

<style scoped></style>
